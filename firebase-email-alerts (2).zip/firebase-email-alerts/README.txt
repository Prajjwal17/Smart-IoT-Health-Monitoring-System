🚨 How to Securely Use Your Gmail Password

1. Do NOT hardcode your password into index.js.
2. Instead, use Firebase environment variables:
   Run this in terminal:
   firebase functions:config:set gmail.email="YOUR_EMAIL" gmail.pass="YOUR_PASSWORD"

3. Then update index.js like this:
   const gmailUser = functions.config().gmail.email;
   const gmailPass = functions.config().gmail.pass;

🔥 OR: If testing locally, replace "YOUR_GMAIL_PASSWORD_HERE" directly
⚠️ But never commit or share your real password!