const functions = require("firebase-functions");
const nodemailer = require("nodemailer");

// Gmail credentials
const gmailUser = "prajjwalpandey1707@gmail.com";
const gmailPass = "YOUR_GMAIL_PASSWORD_HERE"; // ← replace this securely

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: gmailUser,
    pass: gmailPass,
  },
});

exports.alertOnCriticalVitals = functions.firestore
  .document("vital_signs/{entryId}")
  .onCreate(async (snap, context) => {
    const data = snap.data();
    const { heartRate, spo2, temperature } = data;

    if (heartRate > 120 || spo2 < 92 || temperature > 39) {
      const mailOptions = {
        from: `"Vital Sign Monitor" <${gmailUser}>`,
        to: gmailUser,
        subject: "🚨 Vital Alert: Abnormal Vitals Detected",
        html: `
          <h3>⚠️ Health Alert</h3>
          <p><b>Heart Rate:</b> ${heartRate} bpm</p>
          <p><b>SpO₂:</b> ${spo2} %</p>
          <p><b>Temperature:</b> ${temperature} °C</p>
        `,
      };

      try {
        await transporter.sendMail(mailOptions);
        console.log("✅ Email sent successfully.");
      } catch (error) {
        console.error("❌ Failed to send email:", error);
      }
    } else {
      console.log("Vitals normal, no alert sent.");
    }

    return null;
  });